<div class="container">
    <div class="card" style="width: 18rem;">
    <img src="<?= base_url('assets/foto/') . $pengunjung['foto']; ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?= $pengunjung['nis']; ?></h5>
            <p class="card-text"><?= $pengunjung['nama']; ?></p>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?= $pengunjung['angkatan']; ?></li>
            <li class="list-group-item"><?= $pengunjung['jurusan']; ?></li>
            <li class="list-group-item"><?= $pengunjung['email']; ?></li>
            <li class="list-group-item"><?= $pengunjung['hp']; ?></li>
            <li class="list-group-item"><?= $pengunjung['alamat']; ?></li>
        </ul>
        <div class="card-body">
            <a href="<?= base_url('pengunjung'); ?>" class="btn btn-primary">Kembali</a>
        </div>
    </div>
</div>

