<div class="container">
    <form action="" method="post">
        <legend>Tambah Data Petugas</legend>
        <div class="mb-3">
            <label for="petugas" class="form-label">Nama Petugas</label>
            <input type="text" class="form-control" id="petugas" name="petugas" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('petugas'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>