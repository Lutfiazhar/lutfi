<div class="container">
    <form action="" method="post">
        <legend>Ubah Data Petugas</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $petugas['id']; ?>">
            <label for="petugas" class="form-label">Nama Petugas</label>
            <input type="text" class="form-control" id="petugas" name="petugas" value="<?= $petugas['petugas']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('petugas'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>