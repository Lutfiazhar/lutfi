<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengunjung extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_pengunjung');
        $this->load->model('Model_petugas');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'pen';
        if ($this->input->post('submit')) {
            $data['keyword'] = $this->input->post('keyword');
        } else {
            $data['keyword'] = null;
        }
        
        $data['pengunjung'] = $this->Model_pengunjung->getAllPengunjung($data['keyword']);
       
        $this->load->view('templates/header.php', $data);
        $this->load->view('pengunjung/index.php', $data);
        $this->load->view('templates/footer.php');
    }
    
    public function tambah()
    {
        $data['petugas'] = $this->Model_petugas->getAllPetugas();
        $this->form_validation->set_rules('nis', 'Nis', 'trim|required|numeric');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('angkatan', 'Angkatan', 'trim|required|numeric');
        $this->form_validation->set_rules('jurusan', 'Jurusan', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('hp', 'Hp', 'trim|required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah pengunjung';

            $this->load->view('templates/header.php', $data);
            $this->load->view('pengunjung/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_pengunjung->Tambahpengunjung();
            redirect('pengunjung');
        }
        
    }

    public function ubah($id)
    {
        $data['pengunjung'] = $this->Model_pengunjung->getpPengunjungById($id);
        $data['petugas'] = $this->Model_petugas->getAllPetugas();
        $this->form_validation->set_rules('nis', 'Nis', 'trim|required|numeric');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('angkatan', 'Angkatan', 'trim|required|numeric');
        $this->form_validation->set_rules('jurusan', 'Jurusan', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('hp', 'Hp', 'trim|required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah pengunjung';

            $this->load->view('templates/header.php', $data);
            $this->load->view('pengunjung/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_pengunjung->Ubahpengunjung();
            $old_image = $data['pengunjung']['foto'];
            unlink(FCPATH . 'assets/foto/' . $old_image);
            $this->session->set_flashdata('flash', 'Diubahkan');
            redirect('pengunjung');
        }
        
    }

    public function detail($id)
    {
        $data['pengunjung'] = $this->Model_pengunjung->getPengunjungById($id);
       
        $data['title'] = 'Detail pen';
        $this->load->view('templates/header.php', $data);
        $this->load->view('pengunjung/detail.php', $data);
        $this->load->view('templates/footer.php');

    }

    public function hapus($id)
    {
        $data['pengunjung'] = $this->Model_pengunjung->getPengunjungById($id);
        $old_image = $data['pengunjung']['foto'];
        unlink(FCPATH . 'assets/foto/' . $old_image);
        $this->Model_pengunjung->hapuspengunjung($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('pengunjung');
    }
}