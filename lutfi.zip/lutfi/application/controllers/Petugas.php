<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Petugas extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_petugas');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] =  'Petugas';

        $data['petugas'] = $this->Model_petugas->getAllPetugas();
        if( $this->input->post('keyword') ) {
            $data['petugas'] = $this->Model_petugas->Caripetugas();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('petugas/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('petugas',  'Petugas', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Petugas';

            $this->load->view('templates/header.php', $data);
            $this->load->view('petugas/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_petugas->Tambahpetugas();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('petugas');
        }
        
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('petugas',  'Petugas', 'trim|required');
        $data['petugas'] = $this->Model_petugas->getPetugasById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Petugas';

            $this->load->view('templates/header.php', $data);
            $this->load->view('petugas/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_petugas->Ubahpetugas();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('petugas');
        }
        
    }

    public function hapus($id)
    {
        $this->Model_petugas->hapuspetugas($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('petugas');
    }
}
