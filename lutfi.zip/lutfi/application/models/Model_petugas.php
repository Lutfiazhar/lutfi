<?php
class Model_petugas extends CI_Model 
{
    public function getAllPetugas()
    {
        return $query = $this->db->get('petugas')->result_array();
    }

    public function Tambahpetugas()
    {
        $data = [
            "petugas" => $this->input->post('petugas', true)
        ];

        $this->db->insert('petugas', $data);
    }

    public function Ubahpetugas()
    {
        $data = [
            "petugas" => $this->input->post('petugas', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('petugas', $data);
    }

    public function hapusPetugas($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('petugas');
    }

    public function getPetugasById($id)
    {
        return $this->db->get_where('petugas', ['id' => $id])->row_array();
    }

    public function Caripetugas()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('petugas', $keyword);
        return $this->db->get('petugas')->result_array();
    }
}

?>